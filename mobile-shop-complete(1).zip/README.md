# Mobile Shop Management System - Modular Version

A comprehensive mobile phone shop management system built with Python and Tkinter, organized into separate modules for better maintainability.

## 🏗️ **Project Structure**

\`\`\`
mobile-shop-application/
├── main.py                    # Main application entry point
├── database_manager.py        # Database operations and management
├── image_manager.py          # Image handling and management
├── phone_data.py             # Phone inventory data
├── user_manager.py           # User authentication and management
├── ui_components.py          # User interface components
├── requirements.txt          # Python dependencies
├── README.md                # This file
├── images/                  # Phone images directory
├── exports/                 # CSV exports directory
└── backups/                 # Database backups directory
\`\`\`

## 🚀 **Key Features**

### 🔐 **Dynamic User System**
- **Customer name input**: Users enter their real name during login
- **Flexible authentication**: Demo login with username "demo" and password "1234"
- **Personalized experience**: User's name appears throughout the application
- **Session management**: Proper login/logout functionality

### 📱 **Phone Management**
- **6 Brands**: Vivo, Samsung, Apple, Realme, OnePlus, Oppo
- **36 Models**: 6 models per brand with detailed specifications
- **Dynamic pricing**: Real market prices with proper formatting
- **Image support**: Add, view, and manage phone images

### 🗄️ **Database Features**
- **MySQL integration**: Secure database configuration
- **Order tracking**: Complete order management system
- **Customer data**: Store and retrieve customer information
- **Statistics**: Business analytics and reporting

## 📋 **Installation & Setup**

### 1. **Install Dependencies**
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. **Setup MySQL Database**
- Install MySQL Server on your system
- Create a MySQL user with appropriate permissions
- The application will prompt for database configuration on first run

### 3. **Run the Application**
\`\`\`bash
python main.py
\`\`\`

## 🔧 **Module Descriptions**

### **main.py**
- Application entry point
- Initializes all managers and components
- Handles application lifecycle

### **database_manager.py**
- MySQL database connection and configuration
- Order insertion and retrieval
- Statistics generation
- Database cleanup and error handling

### **image_manager.py**
- Image loading and resizing using PIL/Pillow
- Image browsing and selection
- Image viewing in popup windows
- Fallback support for basic image handling

### **phone_data.py**
- Phone inventory data structure
- Brand and model information
- Specifications and pricing
- Easy data management and retrieval

### **user_manager.py**
- Dynamic user authentication
- Customer name input and validation
- Session management
- Login/logout functionality

### **ui_components.py**
- All user interface components
- Window management and navigation
- Form handling and validation
- Admin panel and statistics display

## 👤 **User Experience**

### **Customer Login Process**
1. **Enter your real name** in the "Customer Name" field
2. **Use "demo"** as username
3. **Use "1234"** as password
4. **Your name will appear** throughout the application

### **Navigation Flow**
1. **Home Page** → Enter Shop
2. **Login** → Enter your name and credentials
3. **Welcome Screen** → Shows personalized greeting
4. **Brand Selection** → Choose phone brand
5. **Phone Catalog** → Browse models with images
6. **Order Form** → Pre-filled with your name
7. **Confirmation** → Order completed with details

## 🛠️ **Configuration**

### **Database Configuration**
- **Host**: localhost (default)
- **Port**: 3306 (default)
- **Username**: root (default)
- **Password**: [Your MySQL password]
- **Database**: mobail (default)

### **Image Configuration**
- **Directory**: `images/` (auto-created)
- **Formats**: JPG, JPEG, PNG, GIF, BMP
- **Size**: Auto-resized to optimal dimensions
- **Management**: Built-in image manager

## 📊 **Admin Features**

### **Order Management**
- View all customer orders
- Export orders to CSV
- Order statistics and analytics
- Real-time order tracking

### **Business Statistics**
- Total orders and revenue
- Orders by brand
- Daily order counts
- Customer analytics

## 🔒 **Security Features**

- **No auto-fill passwords**: Enhanced security
- **Input validation**: Prevents invalid data
- **Database error handling**: Graceful error management
- **Safe window grabbing**: Prevents application crashes

## 🎯 **Usage Examples**

### **Customer Registration**
\`\`\`
Customer Name: John Smith
Username: demo
Password: 1234
\`\`\`

### **Order Process**
1. Login with your name
2. Browse phones by brand
3. Select desired model
4. Fill order form (name pre-filled)
5. Confirm order
6. Receive confirmation

## 🐛 **Troubleshooting**

### **Common Issues**

1. **Database Connection Failed**
   - Ensure MySQL server is running
   - Check credentials are correct
   - Verify MySQL port accessibility

2. **Image Not Loading**
   - Use Image Manager to add images
   - Check supported formats (JPG, PNG, etc.)
   - Verify file permissions

3. **Login Issues**
   - Use "demo" as username
   - Use "1234" as password
   - Enter your real name in Customer Name field

## 📞 **Support**

For technical support:
- 📧 Email: support@mobileshop.com
- 📱 Phone: +91-9876543210

## 📝 **License**

This project is for educational and commercial use. All rights reserved.

---

**© 2024 Mobile Shop Management System - Modular Edition**
