import mysql.connector
from mysql.connector import Error
import tkinter as tk
from tkinter import messagebox

class DatabaseManager:
    def __init__(self):
        self.connection = None
        self.cursor = None
    
    def safe_grab_set(self, window):
        """Safely set grab on window with error handling"""
        try:
            window.grab_set()
            return True
        except tk.TclError as e:
            print(f"Warning: Could not set window grab: {e}")
            return False
    
    def setup_database(self, root):
        """Setup MySQL database connection with user input for password"""
        try:
            # Get database credentials from user
            db_window = tk.Toplevel(root)
            db_window.title("Database Configuration")
            db_window.geometry("400x350")
            db_window.configure(bg="#2C3E50")
            db_window.resizable(False, False)
            
            # Try to set grab, but don't fail if it doesn't work
            self.safe_grab_set(db_window)
            
            # Title
            tk.Label(
                db_window,
                text="🗄️ Database Configuration",
                font=("Arial", 16, "bold"),
                fg="white",
                bg="#2C3E50"
            ).pack(pady=20)
            
            # Database fields
            fields_frame = tk.Frame(db_window, bg="#2C3E50")
            fields_frame.pack(pady=20, padx=30, fill="both", expand=True)
            
            # Host
            tk.Label(fields_frame, text="Host:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            host_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            host_entry.pack(pady=5)
            host_entry.insert(0, "localhost")
            
            # Port
            tk.Label(fields_frame, text="Port:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            port_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            port_entry.pack(pady=5)
            port_entry.insert(0, "3306")
            
            # Username
            tk.Label(fields_frame, text="Username:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            username_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            username_entry.pack(pady=5)
            username_entry.insert(0, "root")
            
            # Password
            tk.Label(fields_frame, text="Password:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            password_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25, show="*")
            password_entry.pack(pady=5)
            
            # Database name
            tk.Label(fields_frame, text="Database Name:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            db_name_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            db_name_entry.pack(pady=5)
            db_name_entry.insert(0, "mobail")
            
            # Connection status
            status_label = tk.Label(fields_frame, text="", font=("Arial", 10), bg="#2C3E50")
            status_label.pack(pady=5)
            
            def test_connection():
                try:
                    test_conn = mysql.connector.connect(
                        host=host_entry.get() or "localhost",
                        user=username_entry.get() or "root",
                        password=password_entry.get(),
                        port=int(port_entry.get() or 3306)
                    )
                    test_conn.close()
                    status_label.config(text="✅ Connection successful!", fg="lightgreen")
                    return True
                except Error as e:
                    status_label.config(text=f"❌ Connection failed: {str(e)[:30]}...", fg="lightcoral")
                    return False
            
            def connect_database():
                if test_connection():
                    try:
                        self.connection = mysql.connector.connect(
                            host=host_entry.get() or "localhost",
                            user=username_entry.get() or "root",
                            password=password_entry.get(),
                            port=int(port_entry.get() or 3306),
                            autocommit=True
                        )
                        self.cursor = self.connection.cursor(buffered=True)
                        
                        # Create database if not exists
                        db_name = db_name_entry.get() or "mobail"
                        self.cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
                        self.cursor.execute(f"USE {db_name}")
                        
                        # Create improved table structure
                        create_table_query = """
                        CREATE TABLE IF NOT EXISTS cusdetais (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            customername VARCHAR(100) NOT NULL,
                            state VARCHAR(50) NOT NULL,
                            city VARCHAR(50) NOT NULL,
                            address TEXT NOT NULL,
                            mobail_no VARCHAR(15) NOT NULL,
                            companyname VARCHAR(50) NOT NULL,
                            mobailname VARCHAR(100) NOT NULL,
                            price VARCHAR(20) NOT NULL,
                            specs VARCHAR(200),
                            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            status VARCHAR(20) DEFAULT 'Pending',
                            INDEX idx_customer (customername),
                            INDEX idx_company (companyname),
                            INDEX idx_date (order_date)
                        )
                        """
                        self.cursor.execute(create_table_query)
                        
                        messagebox.showinfo("Success", "Database connected successfully!")
                        db_window.destroy()
                        
                    except Error as e:
                        messagebox.showerror("Database Error", f"Error setting up database: {e}")
                        self.connection = None
                        self.cursor = None
            
            # Buttons
            button_frame = tk.Frame(db_window, bg="#2C3E50")
            button_frame.pack(pady=20)
            
            tk.Button(
                button_frame,
                text="🔍 Test Connection",
                font=("Arial", 10),
                bg="#3498DB",
                fg="white",
                padx=15,
                pady=5,
                command=test_connection
            ).pack(side="left", padx=5)
            
            tk.Button(
                button_frame,
                text="✅ Connect",
                font=("Arial", 12),
                bg="#27AE60",
                fg="white",
                padx=20,
                pady=8,
                command=connect_database
            ).pack(side="left", padx=5)
            
            tk.Button(
                button_frame,
                text="❌ Cancel",
                font=("Arial", 12),
                bg="#E74C3C",
                fg="white",
                padx=20,
                pady=8,
                command=lambda: [setattr(self, 'connection', None), setattr(self, 'cursor', None), db_window.destroy()]
            ).pack(side="left", padx=5)
            
            # Focus on password field
            password_entry.focus()
            
            # Wait for window to close
            root.wait_window(db_window)
            
        except Exception as e:
            messagebox.showerror("Database Setup Error", f"Error in database setup: {e}")
            self.connection = None
            self.cursor = None
    
    def insert_order(self, customer_data, brand, phone):
        """Insert order into database"""
        if not self.connection or not self.cursor:
            raise Exception("Database connection not available")
        
        try:
            query = """
            INSERT INTO cusdetais (customername, state, city, address, mobail_no,
                                 companyname, mobailname, price, specs, status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (
                customer_data["Customer Name"],
                customer_data["State"],
                customer_data["City"],
                customer_data["Address"],
                customer_data["Mobile No"],
                brand,
                phone["name"],
                phone["price"],
                phone.get("specs", ""),
                "Confirmed"
            )
            
            self.cursor.execute(query, values)
            return True
            
        except Error as e:
            raise Exception(f"Error placing order: {e}")
    
    def get_all_orders(self):
        """Get all orders from database"""
        if not self.connection or not self.cursor:
            return []
        
        try:
            self.cursor.execute("""
                SELECT id, customername, mobailname, companyname, price, 
                       mobail_no, city, order_date, status 
                FROM cusdetais 
                ORDER BY order_date DESC
            """)
            return self.cursor.fetchall()
        except Error as e:
            print(f"Error fetching orders: {e}")
            return []
    
    def get_customer_orders(self, customer_name):
        """Get orders for specific customer"""
        if not self.connection or not self.cursor:
            return []
        
        try:
            self.cursor.execute("""
                SELECT id, mobailname, companyname, price, order_date, status 
                FROM cusdetais 
                WHERE customername = %s
                ORDER BY order_date DESC
            """, (customer_name,))
            return self.cursor.fetchall()
        except Error as e:
            print(f"Error fetching customer orders: {e}")
            return []
    
    def get_statistics(self):
        """Get business statistics"""
        if not self.connection or not self.cursor:
            return None
        
        try:
            stats = {}
            
            # Total orders
            self.cursor.execute("SELECT COUNT(*) FROM cusdetais")
            stats['total_orders'] = self.cursor.fetchone()[0]
            
            # Total revenue
            self.cursor.execute("SELECT SUM(CAST(REPLACE(price, ',', '') AS UNSIGNED)) FROM cusdetais")
            stats['total_revenue'] = self.cursor.fetchone()[0] or 0
            
            # Orders by brand
            self.cursor.execute("SELECT companyname, COUNT(*) FROM cusdetais GROUP BY companyname")
            stats['brand_stats'] = self.cursor.fetchall()
            
            # Today's orders
            self.cursor.execute("SELECT COUNT(*) FROM cusdetais WHERE DATE(order_date) = CURDATE()")
            stats['today_orders'] = self.cursor.fetchone()[0]
            
            return stats
            
        except Error as e:
            print(f"Error getting statistics: {e}")
            return None
    
    def cleanup(self):
        """Clean up database connections"""
        try:
            if hasattr(self, 'cursor') and self.cursor:
                self.cursor.close()
            if hasattr(self, 'connection') and self.connection and self.connection.is_connected():
                self.connection.close()
                print("Database connection closed successfully!")
        except Exception as e:
            print(f"Error closing database connection: {e}")
