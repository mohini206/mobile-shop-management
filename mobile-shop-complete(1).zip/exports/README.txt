CSV Exports Directory
====================

This folder stores CSV files exported from the Mobile Shop application.

Export Features:
- Order data export from Admin Panel
- Customer information export
- Sales reports and statistics
- Backup data files

File Format:
- All exports are in CSV format
- UTF-8 encoding for international characters
- Compatible with Excel, Google Sheets, and other spreadsheet applications

How to Export:
1. Go to Admin Panel
2. Click "Export to CSV" button
3. Choose save location (defaults to this folder)
4. File will be saved with timestamp
