import os
import tkinter as tk
from tkinter import filedialog, messagebox
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("PIL not available. Using basic image handling.")

class ImageManager:
    def __init__(self, images_dir="images"):
        self.images_dir = images_dir
        if not os.path.exists(self.images_dir):
            os.makedirs(self.images_dir)
    
    def load_and_resize_image(self, image_path, size=(200, 200)):
        """Load and resize image using PIL if available"""
        try:
            if PIL_AVAILABLE and os.path.exists(image_path):
                # Open image with PIL
                pil_image = Image.open(image_path)
                # Resize image
                pil_image = pil_image.resize(size, Image.Resampling.LANCZOS)
                # Convert to PhotoImage
                return ImageTk.PhotoImage(pil_image)
            elif os.path.exists(image_path):
                # Fallback to basic PhotoImage
                return tk.PhotoImage(file=image_path)
            else:
                return None
        except Exception as e:
            print(f"Error loading image {image_path}: {e}")
            return None
    
    def browse_image(self, phone_data, brand):
        """Browse and select image for a phone"""
        file_path = filedialog.askopenfilename(
            title=f"Select image for {phone_data['name']}",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.bmp"),
                ("JPEG files", "*.jpg *.jpeg"),
                ("PNG files", "*.png"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            # Copy image to images directory
            import shutil
            filename = f"{brand.lower()}_{phone_data['name'].lower().replace(' ', '_')}.jpg"
            destination = os.path.join(self.images_dir, filename)
            
            try:
                shutil.copy2(file_path, destination)
                phone_data['image'] = destination
                messagebox.showinfo("Success", f"Image updated for {phone_data['name']}")
                return destination
            except Exception as e:
                messagebox.showerror("Error", f"Failed to copy image: {e}")
                return None
        return None
    
    def view_image(self, image_path, root):
        """View image in a popup window"""
        if not os.path.exists(image_path):
            messagebox.showerror("Error", "Image file not found!")
            return
        
        view_window = tk.Toplevel(root)
        view_window.title("Image Viewer")
        view_window.configure(bg="white")
        
        try:
            if PIL_AVAILABLE:
                # Load and display image with PIL
                pil_image = Image.open(image_path)
                # Resize if too large
                max_size = (600, 600)
                pil_image.thumbnail(max_size, Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(pil_image)
                
                # Set window size based on image
                view_window.geometry(f"{pil_image.width + 40}x{pil_image.height + 80}")
            else:
                # Fallback to basic PhotoImage
                photo = tk.PhotoImage(file=image_path)
                view_window.geometry("400x400")
            
            # Display image
            img_label = tk.Label(view_window, image=photo, bg="white")
            img_label.image = photo  # Keep reference
            img_label.pack(pady=20)
            
            # Close button
            tk.Button(
                view_window,
                text="✖️ Close",
                font=("Arial", 12),
                bg="#E74C3C",
                fg="white",
                padx=20,
                pady=8,
                command=view_window.destroy
            ).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {e}")
            view_window.destroy()
