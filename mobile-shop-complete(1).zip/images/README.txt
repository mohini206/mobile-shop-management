Phone Images Directory
=====================

This folder is for storing phone images used in the Mobile Shop application.

Image Guidelines:
- Supported formats: JPG, JPEG, PNG, GIF, BMP
- Recommended size: 300x300 pixels or larger
- File naming: Use descriptive names (e.g., "iphone_15.jpg", "samsung_s23.jpg")

How to Add Images:
1. Use the "Image Manager" in the application
2. Click "Browse Image" for any phone model
3. Select your image file
4. The image will be automatically copied to this folder

Note: Images are automatically resized for optimal display in the application.
