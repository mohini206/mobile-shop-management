import tkinter as tk
from tkinter import messagebox
from database_manager import DatabaseManager
from image_manager import ImageManager
from phone_data import PhoneData
from user_manager import UserManager
from ui_components import UIComponents

class MobileShop:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Mobile Shop Management System")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1CD1CE")
        self.root.resizable(True, True)
        
        # Initialize managers
        self.db_manager = DatabaseManager()
        self.image_manager = ImageManager()
        self.phone_data = PhoneData()
        self.user_manager = UserManager()
        
        # Initialize UI components
        self.ui = UIComponents(
            self.root, 
            self.db_manager, 
            self.image_manager, 
            self.phone_data, 
            self.user_manager
        )
        
        # Setup database
        self.db_manager.setup_database(self.root)
        
        # Create main window
        self.ui.create_main_window()
    
    def run(self):
        """Start the application"""
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except Exception as e:
            messagebox.showerror("Application Error", f"An error occurred: {e}")
        finally:
            self.db_manager.cleanup()
    
    def on_closing(self):
        """Handle application closing"""
        if messagebox.askokcancel("Quit", "Do you want to quit the Mobile Shop application?"):
            self.db_manager.cleanup()
            self.root.destroy()

# Run the application
if __name__ == "__main__":
    try:
        app = MobileShop()
        app.run()
    except Exception as e:
        print(f"Failed to start application: {e}")
        messagebox.showerror("Startup Error", f"Failed to start application: {e}")
