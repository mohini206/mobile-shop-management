import tkinter as tk
from tkinter import ttk, messagebox, Canvas, PhotoImage, filedialog
import mysql.connector
from mysql.connector import Error
import os
from datetime import datetime
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("PIL not available. Using basic image handling.")

class MobileShop:
    def __init__(self):
        self.setup_database()
        self.root = tk.Tk()
        self.root.title("Mobile Shop Management System")
        self.root.geometry("1200x800")
        self.root.configure(bg="#1CD1CE")
        self.root.resizable(True, True)
        
        # Create images directory if it doesn't exist
        self.images_dir = "images"
        if not os.path.exists(self.images_dir):
            os.makedirs(self.images_dir)
            messagebox.showinfo("Info", f"Created '{self.images_dir}' directory for phone images.\nPlease add phone images to this folder.")
        
        # Store phone data with image paths
        self.phones = {
            "Vivo": [
                {"name": "Vivo Y35", "price": "18,499", "image": "images/vivo_y35.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Vivo V27 Pro", "price": "35,999", "image": "images/vivo_v27_pro.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Vivo T2x", "price": "16,990", "image": "images/vivo_t2x.jpg", "specs": "4GB RAM, 128GB Storage"},
                {"name": "Vivo X90", "price": "54,999", "image": "images/vivo_x90.jpg", "specs": "12GB RAM, 256GB Storage"},
                {"name": "Vivo V25 Pro", "price": "35,999", "image": "images/vivo_v25_pro.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Vivo Y16", "price": "11,999", "image": "images/vivo_y16.jpg", "specs": "3GB RAM, 64GB Storage"}
            ],
            "Samsung": [
                {"name": "Galaxy S23", "price": "74,999", "image": "images/samsung_s23.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Galaxy A54", "price": "38,999", "image": "images/samsung_a54.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Galaxy M34", "price": "18,999", "image": "images/samsung_m34.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Galaxy S22", "price": "57,999", "image": "images/samsung_s22.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Galaxy A34", "price": "30,999", "image": "images/samsung_a34.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Galaxy M14", "price": "14,990", "image": "images/samsung_m14.jpg", "specs": "4GB RAM, 128GB Storage"}
            ],
            "Apple": [
                {"name": "iPhone 15", "price": "79,900", "image": "images/iphone_15.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 14", "price": "69,900", "image": "images/iphone_14.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 13", "price": "59,900", "image": "images/iphone_13.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 15 Pro", "price": "1,34,900", "image": "images/iphone_15_pro.jpg", "specs": "256GB Storage"},
                {"name": "iPhone 14 Pro", "price": "1,29,900", "image": "images/iphone_14_pro.jpg", "specs": "256GB Storage"},
                {"name": "iPhone SE", "price": "43,900", "image": "images/iphone_se.jpg", "specs": "64GB Storage"}
            ],
            "Realme": [
                {"name": "Realme 11 Pro", "price": "25,999", "image": "images/realme_11_pro.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Realme GT Neo 5", "price": "32,999", "image": "images/realme_gt_neo5.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Realme C55", "price": "13,999", "image": "images/realme_c55.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Realme 10 Pro+", "price": "24,999", "image": "images/realme_10_pro_plus.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Realme Narzo 60", "price": "17,999", "image": "images/realme_narzo_60.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Realme C53", "price": "10,999", "image": "images/realme_c53.jpg", "specs": "4GB RAM, 128GB Storage"}
            ],
            "OnePlus": [
                {"name": "OnePlus 11", "price": "56,999", "image": "images/oneplus_11.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus Nord 3", "price": "33,999", "image": "images/oneplus_nord_3.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus 10R", "price": "38,999", "image": "images/oneplus_10r.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus 11R", "price": "39,999", "image": "images/oneplus_11r.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "OnePlus Nord CE 3", "price": "26,999", "image": "images/oneplus_nord_ce3.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus Nord CE 3 Lite", "price": "19,999", "image": "images/oneplus_nord_ce3_lite.jpg", "specs": "8GB RAM, 128GB Storage"}
            ],
            "Oppo": [
                {"name": "Oppo Reno 10 Pro", "price": "39,999", "image": "images/oppo_reno_10_pro.jpg", "specs": "12GB RAM, 256GB Storage"},
                {"name": "Oppo F23", "price": "25,999", "image": "images/oppo_f23.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo A98", "price": "18,999", "image": "images/oppo_a98.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo Find N3", "price": "1,39,999", "image": "images/oppo_find_n3.jpg", "specs": "16GB RAM, 512GB Storage"},
                {"name": "Oppo A78", "price": "17,999", "image": "images/oppo_a78.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo A58", "price": "13,999", "image": "images/oppo_a58.jpg", "specs": "6GB RAM, 128GB Storage"}
            ]
        }
        
        self.create_main_window()

    def safe_grab_set(self, window):
        """Safely set grab on window with error handling"""
        try:
            window.grab_set()
            return True
        except tk.TclError as e:
            print(f"Warning: Could not set window grab: {e}")
            return False

    def setup_database(self):
        """Setup MySQL database connection with user input for password"""
        try:
            # Get database credentials from user
            db_window = tk.Toplevel()
            db_window.title("Database Configuration")
            db_window.geometry("400x350")
            db_window.configure(bg="#2C3E50")
            db_window.resizable(False, False)
            
            # Try to set grab, but don't fail if it doesn't work
            self.safe_grab_set(db_window)
            
            # Title
            tk.Label(
                db_window,
                text="🗄️ Database Configuration",
                font=("Arial", 16, "bold"),
                fg="white",
                bg="#2C3E50"
            ).pack(pady=20)
            
            # Database fields
            fields_frame = tk.Frame(db_window, bg="#2C3E50")
            fields_frame.pack(pady=20, padx=30, fill="both", expand=True)
            
            # Host
            tk.Label(fields_frame, text="Host:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            host_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            host_entry.pack(pady=5)
            host_entry.insert(0, "localhost")
            
            # Port
            tk.Label(fields_frame, text="Port:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            port_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            port_entry.pack(pady=5)
            port_entry.insert(0, "3306")
            
            # Username
            tk.Label(fields_frame, text="Username:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            username_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            username_entry.pack(pady=5)
            username_entry.insert(0, "root")
            
            # Password
            tk.Label(fields_frame, text="Password:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            password_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25, show="*")
            password_entry.pack(pady=5)
            
            # Database name
            tk.Label(fields_frame, text="Database Name:", font=("Arial", 12), fg="white", bg="#2C3E50").pack(anchor="w", pady=2)
            db_name_entry = tk.Entry(fields_frame, font=("Arial", 12), width=25)
            db_name_entry.pack(pady=5)
            db_name_entry.insert(0, "mobail")
            
            # Connection status
            status_label = tk.Label(fields_frame, text="", font=("Arial", 10), bg="#2C3E50")
            status_label.pack(pady=5)
            
            def test_connection():
                try:
                    test_conn = mysql.connector.connect(
                        host=host_entry.get() or "localhost",
                        user=username_entry.get() or "root",
                        password=password_entry.get(),
                        port=int(port_entry.get() or 3306)
                    )
                    test_conn.close()
                    status_label.config(text="✅ Connection successful!", fg="lightgreen")
                    return True
                except Error as e:
                    status_label.config(text=f"❌ Connection failed: {str(e)[:30]}...", fg="lightcoral")
                    return False
            
            def connect_database():
                if test_connection():
                    try:
                        self.connection = mysql.connector.connect(
                            host=host_entry.get() or "localhost",
                            user=username_entry.get() or "root",
                            password=password_entry.get(),
                            port=int(port_entry.get() or 3306),
                            autocommit=True
                        )
                        self.cursor = self.connection.cursor(buffered=True)
                        
                        # Create database if not exists
                        db_name = db_name_entry.get() or "mobail"
                        self.cursor.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
                        self.cursor.execute(f"USE {db_name}")
                        
                        # Create improved table structure
                        create_table_query = """
                        CREATE TABLE IF NOT EXISTS cusdetais (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            customername VARCHAR(100) NOT NULL,
                            state VARCHAR(50) NOT NULL,
                            city VARCHAR(50) NOT NULL,
                            address TEXT NOT NULL,
                            mobail_no VARCHAR(15) NOT NULL,
                            companyname VARCHAR(50) NOT NULL,
                            mobailname VARCHAR(100) NOT NULL,
                            price VARCHAR(20) NOT NULL,
                            specs VARCHAR(200),
                            order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            status VARCHAR(20) DEFAULT 'Pending',
                            INDEX idx_customer (customername),
                            INDEX idx_company (companyname),
                            INDEX idx_date (order_date)
                        )
                        """
                        self.cursor.execute(create_table_query)
                        
                        messagebox.showinfo("Success", "Database connected successfully!")
                        db_window.destroy()
                        
                    except Error as e:
                        messagebox.showerror("Database Error", f"Error setting up database: {e}")
                        self.connection = None
                        self.cursor = None
            
            # Buttons
            button_frame = tk.Frame(db_window, bg="#2C3E50")
            button_frame.pack(pady=20)
            
            tk.Button(
                button_frame,
                text="🔍 Test Connection",
                font=("Arial", 10),
                bg="#3498DB",
                fg="white",
                padx=15,
                pady=5,
                command=test_connection
            ).pack(side="left", padx=5)
            
            tk.Button(
                button_frame,
                text="✅ Connect",
                font=("Arial", 12),
                bg="#27AE60",
                fg="white",
                padx=20,
                pady=8,
                command=connect_database
            ).pack(side="left", padx=5)
            
            tk.Button(
                button_frame,
                text="❌ Cancel",
                font=("Arial", 12),
                bg="#E74C3C",
                fg="white",
                padx=20,
                pady=8,
                command=lambda: [setattr(self, 'connection', None), setattr(self, 'cursor', None), db_window.destroy()]
            ).pack(side="left", padx=5)
            
            # Focus on password field
            password_entry.focus()
            
            # Wait for window to close
            self.root.wait_window(db_window)
            
        except Exception as e:
            messagebox.showerror("Database Setup Error", f"Error in database setup: {e}")
            self.connection = None
            self.cursor = None

    def load_and_resize_image(self, image_path, size=(200, 200)):
        """Load and resize image using PIL if available"""
        try:
            if PIL_AVAILABLE and os.path.exists(image_path):
                # Open image with PIL
                pil_image = Image.open(image_path)
                # Resize image
                pil_image = pil_image.resize(size, Image.Resampling.LANCZOS)
                # Convert to PhotoImage
                return ImageTk.PhotoImage(pil_image)
            elif os.path.exists(image_path):
                # Fallback to basic PhotoImage
                return PhotoImage(file=image_path)
            else:
                return None
        except Exception as e:
            print(f"Error loading image {image_path}: {e}")
            return None

    def browse_image(self, phone_data, brand):
        """Browse and select image for a phone"""
        file_path = filedialog.askopenfilename(
            title=f"Select image for {phone_data['name']}",
            filetypes=[
                ("Image files", "*.jpg *.jpeg *.png *.gif *.bmp"),
                ("JPEG files", "*.jpg *.jpeg"),
                ("PNG files", "*.png"),
                ("All files", "*.*")
            ]
        )
        
        if file_path:
            # Copy image to images directory
            import shutil
            filename = f"{brand.lower()}_{phone_data['name'].lower().replace(' ', '_')}.jpg"
            destination = os.path.join(self.images_dir, filename)
            
            try:
                shutil.copy2(file_path, destination)
                phone_data['image'] = destination
                messagebox.showinfo("Success", f"Image updated for {phone_data['name']}")
                return destination
            except Exception as e:
                messagebox.showerror("Error", f"Failed to copy image: {e}")
                return None
        return None

    def create_main_window(self):
        """Create the main application window with improved design"""
        # Clear the window
        for widget in self.root.winfo_children():
            widget.destroy()
            
        # Main frame
        main_frame = tk.Frame(self.root, bg="#1CD1CE")
        main_frame.pack(fill="both", expand=True)
        
        # Title with shadow effect
        title_shadow = tk.Label(
            main_frame,
            text="MOBILE SHOP",
            font=("Arial", 34, "bold"),
            fg="#000000",
            bg="#1CD1CE"
        )
        title_shadow.pack(pady=(52, 0))
        
        title_label = tk.Label(
            main_frame,
            text="MOBILE SHOP",
            font=("Arial", 32, "bold"),
            fg="white",
            bg="#1CD1CE"
        )
        title_label.pack(pady=(50, 10))
        
        # Subtitle
        subtitle_label = tk.Label(
            main_frame,
            text="Your One-Stop Destination for Latest Smartphones",
            font=("Arial", 14),
            fg="white",
            bg="#1CD1CE"
        )
        subtitle_label.pack(pady=10)
        
        # Features frame
        features_frame = tk.Frame(main_frame, bg="#1CD1CE")
        features_frame.pack(pady=30)
        
        features = [
            "📱 Latest Models Available",
            "🚚 Free Home Delivery",
            "💰 Best Prices Guaranteed"
        ]
        
        for feature in features:
            feature_label = tk.Label(
                features_frame,
                text=feature,
                font=("Arial", 12),
                fg="white",
                bg="#1CD1CE"
            )
            feature_label.pack(pady=5)
        
        # Button frame
        button_frame = tk.Frame(main_frame, bg="#1CD1CE")
        button_frame.pack(pady=40)
        
        # Enter Shop button
        login_btn = tk.Button(
            button_frame,
            text="🏪 Enter Shop",
            font=("Arial", 16, "bold"),
            bg="#4CAF50",
            fg="white",
            padx=40,
            pady=15,
            relief="raised",
            bd=3,
            cursor="hand2",
            command=self.show_login
        )
        login_btn.pack(pady=10)
        
        # Admin button
        admin_btn = tk.Button(
            button_frame,
            text="👨‍💼 Admin Panel",
            font=("Arial", 12),
            bg="#FF9800",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=self.show_admin_panel
        )
        admin_btn.pack(pady=5)
        
        # Image Management button
        image_btn = tk.Button(
            button_frame,
            text="🖼️ Manage Images",
            font=("Arial", 12),
            bg="#9C27B0",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=self.show_image_manager
        )
        image_btn.pack(pady=5)

    def show_image_manager(self):
        """Show image management window"""
        img_window = tk.Toplevel(self.root)
        img_window.title("Image Manager")
        img_window.geometry("1000x700")
        img_window.configure(bg="#34495E")
        
        # Title
        tk.Label(
            img_window,
            text="🖼️ Phone Image Manager",
            font=("Arial", 20, "bold"),
            fg="white",
            bg="#34495E"
        ).pack(pady=20)
        
        # Create notebook for brands
        notebook = ttk.Notebook(img_window)
        notebook.pack(fill="both", expand=True, padx=20, pady=20)
        
        for brand, phones in self.phones.items():
            brand_frame = tk.Frame(notebook, bg="white")
            notebook.add(brand_frame, text=f"📱 {brand}")
            
            # Scrollable frame
            canvas = tk.Canvas(brand_frame, bg="white")
            scrollbar = ttk.Scrollbar(brand_frame, orient="vertical", command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, bg="white")
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            # Add phones
            for i, phone in enumerate(phones):
                phone_frame = tk.Frame(scrollable_frame, bg="#f8f9fa", relief="raised", bd=2, padx=20, pady=15)
                phone_frame.pack(fill="x", padx=20, pady=10)
                
                # Phone info
                info_frame = tk.Frame(phone_frame, bg="#f8f9fa")
                info_frame.pack(side="left", fill="both", expand=True)
                
                tk.Label(info_frame, text=phone["name"], font=("Arial", 14, "bold"), 
                        fg="#333", bg="#f8f9fa").pack(anchor="w")
                tk.Label(info_frame, text=f"Price: ₹{phone['price']}", font=("Arial", 12), 
                        fg="green", bg="#f8f9fa").pack(anchor="w")
                
                # Image status
                image_exists = os.path.exists(phone["image"])
                status_text = "✅ Image Found" if image_exists else "❌ Image Missing"
                status_color = "green" if image_exists else "red"
                
                tk.Label(info_frame, text=f"Status: {status_text}", font=("Arial", 10), 
                        fg=status_color, bg="#f8f9fa").pack(anchor="w")
                tk.Label(info_frame, text=f"Path: {phone['image']}", font=("Arial", 9), 
                        fg="gray", bg="#f8f9fa").pack(anchor="w")
                
                # Buttons
                button_frame = tk.Frame(phone_frame, bg="#f8f9fa")
                button_frame.pack(side="right")
                
                tk.Button(
                    button_frame,
                    text="📁 Browse Image",
                    font=("Arial", 10),
                    bg="#3498DB",
                    fg="white",
                    padx=10,
                    pady=5,
                    command=lambda p=phone, b=brand: self.browse_image(p, b)
                ).pack(pady=2)
                
                if image_exists:
                    tk.Button(
                        button_frame,
                        text="👁️ View Image",
                        font=("Arial", 10),
                        bg="#27AE60",
                        fg="white",
                        padx=10,
                        pady=5,
                        command=lambda path=phone["image"]: self.view_image(path)
                    ).pack(pady=2)
            
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")

    def view_image(self, image_path):
        """View image in a popup window"""
        if not os.path.exists(image_path):
            messagebox.showerror("Error", "Image file not found!")
            return
        
        view_window = tk.Toplevel(self.root)
        view_window.title("Image Viewer")
        view_window.configure(bg="white")
        
        try:
            if PIL_AVAILABLE:
                # Load and display image with PIL
                pil_image = Image.open(image_path)
                # Resize if too large
                max_size = (600, 600)
                pil_image.thumbnail(max_size, Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(pil_image)
                
                # Set window size based on image
                view_window.geometry(f"{pil_image.width + 40}x{pil_image.height + 80}")
            else:
                # Fallback to basic PhotoImage
                photo = PhotoImage(file=image_path)
                view_window.geometry("400x400")
            
            # Display image
            img_label = tk.Label(view_window, image=photo, bg="white")
            img_label.image = photo  # Keep reference
            img_label.pack(pady=20)
            
            # Close button
            tk.Button(
                view_window,
                text="✖️ Close",
                font=("Arial", 12),
                bg="#E74C3C",
                fg="white",
                padx=20,
                pady=8,
                command=view_window.destroy
            ).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load image: {e}")
            view_window.destroy()

    def show_login(self):
        """Show login window without auto-filled password"""
        login_window = tk.Toplevel(self.root)
        login_window.title("Customer Login")
        login_window.geometry("450x400")
        login_window.configure(bg="#0E43D0")
        login_window.resizable(False, False)
        
        # Center the window
        login_window.transient(self.root)
        
        # Try to set grab, but don't fail if it doesn't work
        self.safe_grab_set(login_window)
        
        # Main frame
        main_frame = tk.Frame(login_window, bg="#0E43D0", padx=40, pady=40)
        main_frame.pack(fill="both", expand=True)
        
        # Title
        title_label = tk.Label(
            main_frame,
            text="🔐 Customer Login",
            font=("Arial", 24, "bold"),
            fg="yellow",
            bg="#0E43D0"
        )
        title_label.pack(pady=(0, 30))
        
        # Username field
        tk.Label(
            main_frame,
            text="Username:",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#0E43D0"
        ).pack(anchor="w", pady=(10, 5))
        
        username_entry = tk.Entry(
            main_frame,
            font=("Arial", 14),
            width=25,
            relief="solid",
            bd=2
        )
        username_entry.pack(pady=(0, 15))
        
        # Password field
        tk.Label(
            main_frame,
            text="Password:",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#0E43D0"
        ).pack(anchor="w", pady=(0, 5))
        
        password_entry = tk.Entry(
            main_frame,
            font=("Arial", 14),
            width=25,
            show="*",
            relief="solid",
            bd=2
        )
        password_entry.pack(pady=(0, 20))
        
        # Show password checkbox
        show_password_var = tk.BooleanVar()
        show_password_cb = tk.Checkbutton(
            main_frame,
            text="Show Password",
            variable=show_password_var,
            font=("Arial", 10),
            fg="white",
            bg="#0E43D0",
            selectcolor="#0E43D0",
            command=lambda: password_entry.config(show="" if show_password_var.get() else "*")
        )
        show_password_cb.pack(anchor="w", pady=(0, 10))
        
        def validate_login():
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            
            # Check if fields are empty
            if not username:
                messagebox.showerror("Error", "Please enter username")
                username_entry.focus()
                return
            
            if not password:
                messagebox.showerror("Error", "Please enter password")
                password_entry.focus()
                return
            
            # Validate credentials
            if username == "mohini sakhare" and password == "1234":
                messagebox.showinfo("Success", "🎉 Login Successful! Welcome to Mobile Shop")
                login_window.destroy()
                self.show_brands()
            else:
                messagebox.showerror("Error", "❌ Invalid credentials. Please try again.")
                password_entry.delete(0, tk.END)
                password_entry.focus()
        
        # Login button
        login_btn = tk.Button(
            main_frame,
            text="🚀 Login",
            font=("Arial", 14, "bold"),
            bg="#4CAF50",
            fg="white",
            padx=30,
            pady=10,
            cursor="hand2",
            command=validate_login
        )
        login_btn.pack(pady=10)
        
        # Cancel button
        cancel_btn = tk.Button(
            main_frame,
            text="❌ Cancel",
            font=("Arial", 12),
            bg="#f44336",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=login_window.destroy
        )
        cancel_btn.pack(pady=5)
        
        # Demo credentials info
        info_frame = tk.Frame(main_frame, bg="#0E43D0")
        info_frame.pack(pady=20)
        
        tk.Label(
            info_frame,
            text="Demo Credentials:",
            font=("Arial", 10, "bold"),
            fg="yellow",
            bg="#0E43D0"
        ).pack()
        
        tk.Label(
            info_frame,
            text="Username: mohini sakhare",
            font=("Arial", 9),
            fg="lightblue",
            bg="#0E43D0"
        ).pack()
        
        tk.Label(
            info_frame,
            text="Password: 1234",
            font=("Arial", 9),
            fg="lightblue",
            bg="#0E43D0"
        ).pack()
        
        # Bind Enter key to login
        login_window.bind('<Return>', lambda event: validate_login())
        username_entry.focus()

    def show_brands(self):
        """Show available phone brands with improved layout"""
        brands_window = tk.Toplevel(self.root)
        brands_window.title("Select Phone Brand")
        brands_window.geometry("1100x700")
        brands_window.configure(bg="#E80770")
        brands_window.state('zoomed')
        
        # Main frame
        main_frame = tk.Frame(brands_window, bg="#E80770")
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            main_frame,
            text="🏪 Choose Your Favorite Brand",
            font=("Arial", 28, "bold"),
            fg="#FEF014",
            bg="#E80770"
        )
        title_label.pack(pady=(20, 40))
        
        # Brands frame with grid layout
        brands_frame = tk.Frame(main_frame, bg="#E80770")
        brands_frame.pack(expand=True)
        
        brands_info = [
            ("Vivo", "#9C27B0", "📱"),
            ("Samsung", "#2196F3", "📱"),
            ("Apple", "#607D8B", "🍎"),
            ("Realme", "#FF9800", "📱"),
            ("OnePlus", "#F44336", "📱"),
            ("Oppo", "#4CAF50", "📱")
        ]
        
        for i, (brand, color, icon) in enumerate(brands_info):
            row = i // 3
            col = i % 3
            
            brand_frame = tk.Frame(brands_frame, bg=color, relief="raised", bd=3)
            brand_frame.grid(row=row, column=col, padx=20, pady=20, sticky="nsew")
            
            # Configure grid weights
            brands_frame.grid_rowconfigure(row, weight=1)
            brands_frame.grid_columnconfigure(col, weight=1)
            
            # Brand icon
            icon_label = tk.Label(
                brand_frame,
                text=icon,
                font=("Arial", 40),
                bg=color,
                fg="white"
            )
            icon_label.pack(pady=(20, 10))
            
            # Brand button
            brand_btn = tk.Button(
                brand_frame,
                text=brand,
                font=("Arial", 18, "bold"),
                bg="white",
                fg=color,
                width=12,
                height=2,
                cursor="hand2",
                relief="raised",
                bd=2,
                command=lambda b=brand: self.show_phones(b, brands_window)
            )
            brand_btn.pack(pady=(0, 20))
            
            # Phone count
            count_label = tk.Label(
                brand_frame,
                text=f"{len(self.phones[brand])} Models",
                font=("Arial", 12),
                bg=color,
                fg="white"
            )
            count_label.pack(pady=(0, 10))
        
        # Back button
        back_btn = tk.Button(
            main_frame,
            text="🏠 Back to Home",
            font=("Arial", 12),
            bg="#607D8B",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=lambda: [brands_window.destroy(), self.create_main_window()]
        )
        back_btn.pack(pady=20)

    def show_phones(self, brand, parent_window):
        """Show phones for selected brand with improved image handling"""
        phones_window = tk.Toplevel(parent_window)
        phones_window.title(f"{brand} Phone Collection")
        phones_window.geometry("1200x800")
        phones_window.configure(bg="#06AE32")
        phones_window.state('zoomed')
        
        # Main frame
        main_frame = tk.Frame(phones_window, bg="#06AE32")
        main_frame.pack(fill="both", expand=True)
        
        # Header frame
        header_frame = tk.Frame(main_frame, bg="#06AE32")
        header_frame.pack(fill="x", padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            header_frame,
            text=f"📱 {brand} Collection",
            font=("Arial", 26, "bold"),
            fg="white",
            bg="#06AE32"
        )
        title_label.pack(side="left")
        
        # Back button
        back_btn = tk.Button(
            header_frame,
            text="⬅️ Back to Brands",
            font=("Arial", 12),
            bg="#FF5722",
            fg="white",
            padx=15,
            pady=8,
            cursor="hand2",
            command=phones_window.destroy
        )
        back_btn.pack(side="right")
        
        # Create scrollable frame
        canvas = tk.Canvas(main_frame, bg="#06AE32", highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="#06AE32")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Add phones in grid layout
        if brand in self.phones:
            phones_per_row = 2
            for i, phone in enumerate(self.phones[brand]):
                row = i // phones_per_row
                col = i % phones_per_row
                
                # Phone frame
                phone_frame = tk.Frame(
                    scrollable_frame,
                    bg="white",
                    relief="raised",
                    bd=3,
                    padx=20,
                    pady=20
                )
                phone_frame.grid(row=row, column=col, padx=20, pady=15, sticky="ew")
                
                # Configure grid weights
                scrollable_frame.grid_columnconfigure(col, weight=1)
                
                # Image frame
                image_frame = tk.Frame(phone_frame, bg="#f0f0f0", width=200, height=200)
                image_frame.pack(pady=(0, 15))
                image_frame.pack_propagate(False)
                
                # Try to load image
                photo = self.load_and_resize_image(phone["image"], (180, 180))
                
                if photo:
                    img_label = tk.Label(image_frame, image=photo, bg="#f0f0f0")
                    img_label.image = photo  # Keep reference
                    img_label.pack(expand=True)
                else:
                    # Show placeholder with option to add image
                    placeholder_frame = tk.Frame(image_frame, bg="#f0f0f0")
                    placeholder_frame.pack(expand=True, fill="both")
                    
                    tk.Label(
                        placeholder_frame,
                        text="📱\nNo Image",
                        font=("Arial", 16),
                        fg="gray",
                        bg="#f0f0f0"
                    ).pack(expand=True)
                    
                    tk.Button(
                        placeholder_frame,
                        text="📁 Add Image",
                        font=("Arial", 8),
                        bg="#3498DB",
                        fg="white",
                        command=lambda p=phone, b=brand: self.browse_image(p, b)
                    ).pack(pady=5)
                
                # Phone details
                name_label = tk.Label(
                    phone_frame,
                    text=phone["name"],
                    font=("Arial", 18, "bold"),
                    fg="#333",
                    bg="white"
                )
                name_label.pack(pady=(0, 5))
                
                specs_label = tk.Label(
                    phone_frame,
                    text=phone.get("specs", "Specifications available"),
                    font=("Arial", 11),
                    fg="#666",
                    bg="white"
                )
                specs_label.pack(pady=(0, 10))
                
                price_label = tk.Label(
                    phone_frame,
                    text=f"💰 ₹{phone['price']}",
                    font=("Arial", 16, "bold"),
                    fg="green",
                    bg="white"
                )
                price_label.pack(pady=(0, 15))
                
                # Buttons frame
                buttons_frame = tk.Frame(phone_frame, bg="white")
                buttons_frame.pack(fill="x")
                
                # Buy button
                buy_btn = tk.Button(
                    buttons_frame,
                    text="🛒 Buy Now",
                    font=("Arial", 14, "bold"),
                    bg="#FF5722",
                    fg="white",
                    padx=20,
                    pady=10,
                    cursor="hand2",
                    command=lambda p=phone, b=brand: self.show_order_form(p, b, phones_window)
                )
                buy_btn.pack(side="left", padx=(0, 10))
                
                # Details button
                details_btn = tk.Button(
                    buttons_frame,
                    text="ℹ️ Details",
                    font=("Arial", 12),
                    bg="#2196F3",
                    fg="white",
                    padx=15,
                    pady=8,
                    cursor="hand2",
                    command=lambda p=phone, b=brand: self.show_phone_details(p, b)
                )
                details_btn.pack(side="right")
        
        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True, padx=(20, 0))
        scrollbar.pack(side="right", fill="y", padx=(0, 20))
        
        # Bind mousewheel to canvas
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)

    def show_phone_details(self, phone, brand):
        """Show detailed information about a phone"""
        details_window = tk.Toplevel(self.root)
        details_window.title(f"{phone['name']} - Details")
        details_window.geometry("500x400")
        details_window.configure(bg="white")
        details_window.resizable(False, False)
        
        # Center the window
        details_window.transient(self.root)
        self.safe_grab_set(details_window)
        
        # Main frame
        main_frame = tk.Frame(details_window, bg="white", padx=30, pady=30)
        main_frame.pack(fill="both", expand=True)
        
        # Title
        title_label = tk.Label(
            main_frame,
            text=phone["name"],
            font=("Arial", 20, "bold"),
            fg="#333",
            bg="white"
        )
        title_label.pack(pady=(0, 20))
        
        # Details
        details = [
            ("Brand", brand),
            ("Model", phone["name"]),
            ("Price", f"₹{phone['price']}"),
            ("Specifications", phone.get("specs", "Standard specifications")),
            ("Warranty", "1 Year Manufacturer Warranty"),
            ("Delivery", "Free Home Delivery"),
            ("Return Policy", "7 Days Return Policy")
        ]
        
        for label, value in details:
            detail_frame = tk.Frame(main_frame, bg="white")
            detail_frame.pack(fill="x", pady=5)
            
            tk.Label(
                detail_frame,
                text=f"{label}:",
                font=("Arial", 12, "bold"),
                fg="#555",
                bg="white"
            ).pack(side="left")
            
            tk.Label(
                detail_frame,
                text=value,
                font=("Arial", 12),
                fg="#333",
                bg="white"
            ).pack(side="right")
        
        # Close button
        close_btn = tk.Button(
            main_frame,
            text="✖️ Close",
            font=("Arial", 12),
            bg="#f44336",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=details_window.destroy
        )
        close_btn.pack(pady=20)

    def show_order_form(self, phone, brand, parent_window):
        """Show order form for selected phone with improved validation"""
        order_window = tk.Toplevel(parent_window)
        order_window.title("Place Your Order")
        order_window.geometry("900x700")
        order_window.configure(bg="#DD1D0D")
        order_window.resizable(True, True)
        
        # Main container
        main_container = tk.Frame(order_window, bg="#DD1D0D")
        main_container.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Title
        title_label = tk.Label(
            main_container,
            text="📋 Place Your Order",
            font=("Arial", 24, "bold"),
            fg="yellow",
            bg="#DD1D0D"
        )
        title_label.pack(pady=(0, 20))
        
        # Create notebook for tabs
        notebook = ttk.Notebook(main_container)
        notebook.pack(fill="both", expand=True, pady=(0, 20))
        
        # Customer Details Tab
        customer_frame = tk.Frame(notebook, bg="white", padx=30, pady=30)
        notebook.add(customer_frame, text="👤 Customer Details")
        
        # Product Details Tab
        product_frame = tk.Frame(notebook, bg="white", padx=30, pady=30)
        notebook.add(product_frame, text="📱 Product Details")
        
        # Customer form fields
        tk.Label(
            customer_frame,
            text="Customer Information",
            font=("Arial", 18, "bold"),
            fg="#333",
            bg="white"
        ).pack(pady=(0, 20))
        
        fields = [
            ("Customer Name", "text"),
            ("State", "text"),
            ("City", "text"),
            ("Address", "text"),
            ("Mobile No", "text"),
            ("Email (Optional)", "text")
        ]
        
        entries = {}
        
        for field, field_type in fields:
            field_frame = tk.Frame(customer_frame, bg="white")
            field_frame.pack(fill="x", pady=8)
            
            tk.Label(
                field_frame,
                text=f"{field}:",
                font=("Arial", 12, "bold"),
                fg="#555",
                bg="white",
                width=15,
                anchor="w"
            ).pack(side="left")
            
            if field == "Address":
                entry = tk.Text(
                    field_frame,
                    font=("Arial", 12),
                    width=30,
                    height=3,
                    relief="solid",
                    bd=1
                )
            else:
                entry = tk.Entry(
                    field_frame,
                    font=("Arial", 12),
                    width=30,
                    relief="solid",
                    bd=1
                )
            
            entry.pack(side="right", padx=(10, 0))
            entries[field] = entry
        
        # Pre-fill customer name
        entries["Customer Name"].insert(0, "Mohini Sakhare")
        
        # Product Details Tab Content
        tk.Label(
            product_frame,
            text="Product Information",
            font=("Arial", 18, "bold"),
            fg="#333",
            bg="white"
        ).pack(pady=(0, 20))
        
        product_info = [
            ("Company", brand),
            ("Model", phone["name"]),
            ("Specifications", phone.get("specs", "Standard specifications")),
            ("Price", f"₹{phone['price']}"),
            ("Warranty", "1 Year Manufacturer Warranty"),
            ("Delivery", "Free Home Delivery (2-3 Days)"),
            ("Payment", "Cash on Delivery Available")
        ]
        
        for label, value in product_info:
            info_frame = tk.Frame(product_frame, bg="white")
            info_frame.pack(fill="x", pady=8)
            
            tk.Label(
                info_frame,
                text=f"{label}:",
                font=("Arial", 12, "bold"),
                fg="#555",
                bg="white",
                width=15,
                anchor="w"
            ).pack(side="left")
            
            tk.Label(
                info_frame,
                text=value,
                font=("Arial", 12),
                fg="#333",
                bg="white",
                wraplength=300,
                justify="left"
            ).pack(side="right", padx=(10, 0))
        
        # Buttons frame
        button_frame = tk.Frame(main_container, bg="#DD1D0D")
        button_frame.pack(fill="x", pady=10)
        
        def validate_and_place_order():
            # Get values from entries
            customer_data = {}
            for field, entry in entries.items():
                if field == "Address":
                    value = entry.get("1.0", tk.END).strip()
                else:
                    value = entry.get().strip()
                customer_data[field] = value
            
            # Validation
            required_fields = ["Customer Name", "State", "City", "Address", "Mobile No"]
            for field in required_fields:
                if not customer_data[field]:
                    messagebox.showerror("Validation Error", f"Please fill in the {field} field")
                    return
            
            # Validate mobile number
            mobile = customer_data["Mobile No"]
            if not mobile.isdigit() or len(mobile) != 10:
                messagebox.showerror("Validation Error", "Please enter a valid 10-digit mobile number")
                return
            
            # Check database connection
            if not self.connection or not self.cursor:
                messagebox.showerror("Database Error", "Database connection failed. Please restart the application.")
                return
            
            try:
                # Insert order into database
                query = """
                INSERT INTO cusdetais (customername, state, city, address, mobail_no,
                                     companyname, mobailname, price, specs, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                values = (
                    customer_data["Customer Name"],
                    customer_data["State"],
                    customer_data["City"],
                    customer_data["Address"],
                    customer_data["Mobile No"],
                    brand,
                    phone["name"],
                    phone["price"],
                    phone.get("specs", ""),
                    "Confirmed"
                )
                
                self.cursor.execute(query, values)
                
                # Show success message
                success_msg = f"""
🎉 Order Confirmed Successfully! 🎉

Order Details:
📱 Product: {phone['name']}
💰 Price: ₹{phone['price']}
👤 Customer: {customer_data['Customer Name']}
📞 Mobile: {customer_data['Mobile No']}

📦 Your order will be delivered within 2-3 business days.
💳 Payment: Cash on Delivery
📞 For any queries, contact: +91-9876543210

Thank you for shopping with us! 🙏
                """
                
                messagebox.showinfo("Order Confirmed", success_msg)
                order_window.destroy()
                
            except Error as e:
                messagebox.showerror("Database Error", f"Error placing order: {e}")
        
        # Place Order button
        place_order_btn = tk.Button(
            button_frame,
            text="✅ Place Order",
            font=("Arial", 14, "bold"),
            bg="#4CAF50",
            fg="white",
            padx=30,
            pady=12,
            cursor="hand2",
            command=validate_and_place_order
        )
        place_order_btn.pack(side="left", padx=(0, 20))
        
        # Cancel button
        cancel_btn = tk.Button(
            button_frame,
            text="❌ Cancel",
            font=("Arial", 14),
            bg="#f44336",
            fg="white",
            padx=30,
            pady=12,
            cursor="hand2",
            command=order_window.destroy
        )
        cancel_btn.pack(side="left")
        
        # View Orders button
        view_orders_btn = tk.Button(
            button_frame,
            text="📋 View My Orders",
            font=("Arial", 12),
            bg="#2196F3",
            fg="white",
            padx=20,
            pady=10,
            cursor="hand2",
            command=self.show_customer_orders
        )
        view_orders_btn.pack(side="right")

    def show_customer_orders(self):
        """Show customer's order history"""
        if not self.connection or not self.cursor:
            messagebox.showerror("Database Error", "Database connection not available")
            return
        
        orders_window = tk.Toplevel(self.root)
        orders_window.title("My Orders")
        orders_window.geometry("1000x600")
        orders_window.configure(bg="white")
        
        # Title
        title_label = tk.Label(
            orders_window,
            text="📋 My Order History",
            font=("Arial", 20, "bold"),
            fg="#333",
            bg="white"
        )
        title_label.pack(pady=20)
        
        # Create treeview for orders
        columns = ("Order ID", "Product", "Brand", "Price", "Date", "Status")
        tree = ttk.Treeview(orders_window, columns=columns, show="headings", height=15)
        
        # Define headings
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=150, anchor="center")
        
        # Scrollbar
        scrollbar = ttk.Scrollbar(orders_window, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        
        try:
            # Fetch orders from database
            self.cursor.execute("""
                SELECT id, mobailname, companyname, price, order_date, status 
                FROM cusdetais 
                ORDER BY order_date DESC
            """)
            orders = self.cursor.fetchall()
            
            # Insert orders into treeview
            for order in orders:
                order_id, product, brand, price, date, status = order
                formatted_date = date.strftime("%Y-%m-%d %H:%M") if date else "N/A"
                tree.insert("", "end", values=(order_id, product, brand, f"₹{price}", formatted_date, status))
            
        except Error as e:
            messagebox.showerror("Database Error", f"Error fetching orders: {e}")
        
        # Pack treeview and scrollbar
        tree.pack(side="left", fill="both", expand=True, padx=(20, 0), pady=20)
        scrollbar.pack(side="right", fill="y", padx=(0, 20), pady=20)
        
        # Close button
        close_btn = tk.Button(
            orders_window,
            text="✖️ Close",
            font=("Arial", 12),
            bg="#f44336",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=orders_window.destroy
        )
        close_btn.pack(pady=10)

    def show_admin_panel(self):
        """Show admin panel for managing orders"""
        admin_window = tk.Toplevel(self.root)
        admin_window.title("Admin Panel")
        admin_window.geometry("1200x700")
        admin_window.configure(bg="#263238")
        admin_window.state('zoomed')
        
        # Title
        title_label = tk.Label(
            admin_window,
            text="👨‍💼 Admin Panel - Order Management",
            font=("Arial", 24, "bold"),
            fg="white",
            bg="#263238"
        )
        title_label.pack(pady=20)
        
        # Create notebook for different admin functions
        notebook = ttk.Notebook(admin_window)
        notebook.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Orders tab
        orders_frame = tk.Frame(notebook, bg="white")
        notebook.add(orders_frame, text="📋 All Orders")
        
        # Statistics tab
        stats_frame = tk.Frame(notebook, bg="white")
        notebook.add(stats_frame, text="📊 Statistics")
        
        # Orders management
        self.create_orders_tab(orders_frame)
        self.create_stats_tab(stats_frame)

    def create_orders_tab(self, parent):
        """Create orders management tab"""
        if not self.connection or not self.cursor:
            tk.Label(parent, text="Database connection not available", 
                    font=("Arial", 16), fg="red").pack(pady=50)
            return
        
        # Control frame
        control_frame = tk.Frame(parent, bg="white")
        control_frame.pack(fill="x", padx=20, pady=10)
        
        # Refresh button
        refresh_btn = tk.Button(
            control_frame,
            text="🔄 Refresh",
            font=("Arial", 12),
            bg="#4CAF50",
            fg="white",
            padx=15,
            pady=8,
            cursor="hand2",
            command=lambda: self.refresh_orders_list(tree)
        )
        refresh_btn.pack(side="left", padx=(0, 10))
        
        # Export button
        export_btn = tk.Button(
            control_frame,
            text="📤 Export to CSV",
            font=("Arial", 12),
            bg="#2196F3",
            fg="white",
            padx=15,
            pady=8,
            cursor="hand2",
            command=self.export_orders_to_csv
        )
        export_btn.pack(side="left")
        
        # Create treeview for all orders
        columns = ("ID", "Customer", "Phone", "Brand", "Price", "Mobile", "City", "Date", "Status")
        tree = ttk.Treeview(parent, columns=columns, show="headings", height=20)
        
        # Define headings and column widths
        column_widths = {"ID": 50, "Customer": 120, "Phone": 150, "Brand": 80, 
                        "Price": 80, "Mobile": 100, "City": 100, "Date": 120, "Status": 80}
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=column_widths.get(col, 100), anchor="center")
        
        # Scrollbars
        v_scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        h_scrollbar = ttk.Scrollbar(parent, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Load initial data
        self.refresh_orders_list(tree)
        
        # Pack treeview and scrollbars
        tree.pack(side="left", fill="both", expand=True, padx=(20, 0), pady=10)
        v_scrollbar.pack(side="right", fill="y", pady=10)
        h_scrollbar.pack(side="bottom", fill="x", padx=20)

    def create_stats_tab(self, parent):
        """Create statistics tab"""
        if not self.connection or not self.cursor:
            tk.Label(parent, text="Database connection not available", 
                    font=("Arial", 16), fg="red").pack(pady=50)
            return
        
        try:
            # Get statistics
            stats_frame = tk.Frame(parent, bg="white", padx=40, pady=40)
            stats_frame.pack(fill="both", expand=True)
            
            tk.Label(
                stats_frame,
                text="📊 Business Statistics",
                font=("Arial", 20, "bold"),
                fg="#333",
                bg="white"
            ).pack(pady=(0, 30))
            
            # Total orders
            self.cursor.execute("SELECT COUNT(*) FROM cusdetais")
            total_orders = self.cursor.fetchone()[0]
            
            # Total revenue
            self.cursor.execute("SELECT SUM(CAST(REPLACE(price, ',', '') AS UNSIGNED)) FROM cusdetais")
            total_revenue = self.cursor.fetchone()[0] or 0
            
            # Orders by brand
            self.cursor.execute("SELECT companyname, COUNT(*) FROM cusdetais GROUP BY companyname")
            brand_stats = self.cursor.fetchall()
            
            # Recent orders
            self.cursor.execute("SELECT COUNT(*) FROM cusdetais WHERE DATE(order_date) = CURDATE()")
            today_orders = self.cursor.fetchone()[0]
            
            # Display statistics
            stats_data = [
                ("📱 Total Orders", str(total_orders)),
                ("💰 Total Revenue", f"₹{total_revenue:,}"),
                ("📅 Today's Orders", str(today_orders)),
                ("🏪 Active Brands", str(len(brand_stats)))
            ]
            
            stats_grid = tk.Frame(stats_frame, bg="white")
            stats_grid.pack(pady=20)
            
            for i, (label, value) in enumerate(stats_data):
                row = i // 2
                col = i % 2
                
                stat_frame = tk.Frame(stats_grid, bg="#f5f5f5", relief="raised", bd=2, padx=20, pady=20)
                stat_frame.grid(row=row, column=col, padx=20, pady=10, sticky="ew")
                
                tk.Label(stat_frame, text=label, font=("Arial", 14), fg="#666", bg="#f5f5f5").pack()
                tk.Label(stat_frame, text=value, font=("Arial", 20, "bold"), fg="#333", bg="#f5f5f5").pack()
            
            # Brand-wise orders
            if brand_stats:
                tk.Label(
                    stats_frame,
                    text="📊 Orders by Brand",
                    font=("Arial", 16, "bold"),
                    fg="#333",
                    bg="white"
                ).pack(pady=(40, 20))
                
                brand_frame = tk.Frame(stats_frame, bg="white")
                brand_frame.pack()
                
                for brand, count in brand_stats:
                    brand_stat = tk.Frame(brand_frame, bg="white")
                    brand_stat.pack(fill="x", pady=5)
                    
                    tk.Label(brand_stat, text=f"{brand}:", font=("Arial", 12, "bold"), 
                            fg="#555", bg="white", width=15, anchor="w").pack(side="left")
                    tk.Label(brand_stat, text=f"{count} orders", font=("Arial", 12), 
                            fg="#333", bg="white").pack(side="right")
            
        except Error as e:
            tk.Label(parent, text=f"Error loading statistics: {e}", 
                    font=("Arial", 14), fg="red", bg="white").pack(pady=50)

    def refresh_orders_list(self, tree):
        """Refresh the orders list in admin panel"""
        # Clear existing items
        for item in tree.get_children():
            tree.delete(item)
        
        try:
            # Fetch all orders
            self.cursor.execute("""
                SELECT id, customername, mobailname, companyname, price, 
                       mobail_no, city, order_date, status 
                FROM cusdetais 
                ORDER BY order_date DESC
            """)
            orders = self.cursor.fetchall()
            
            # Insert orders into treeview
            for order in orders:
                order_id, customer, phone, brand, price, mobile, city, date, status = order
                formatted_date = date.strftime("%Y-%m-%d %H:%M") if date else "N/A"
                tree.insert("", "end", values=(
                    order_id, customer, phone, brand, f"₹{price}", 
                    mobile, city, formatted_date, status
                ))
                
        except Error as e:
            messagebox.showerror("Database Error", f"Error fetching orders: {e}")

    def export_orders_to_csv(self):
        """Export orders to CSV file"""
        try:
            import csv
            
            # Ask user for save location
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
                title="Save Orders as CSV"
            )
            
            if filename:
                self.cursor.execute("""
                    SELECT id, customername, mobailname, companyname, price, 
                           mobail_no, city, state, address, order_date, status 
                    FROM cusdetais 
                    ORDER BY order_date DESC
                """)
                orders = self.cursor.fetchall()
                
                with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                    writer = csv.writer(csvfile)
                    # Write header
                    writer.writerow([
                        "Order ID", "Customer Name", "Phone Model", "Brand", "Price",
                        "Mobile No", "City", "State", "Address", "Order Date", "Status"
                    ])
                    # Write data
                    for order in orders:
                        writer.writerow(order)
                
                messagebox.showinfo("Export Successful", f"Orders exported to {filename}")
                
        except Exception as e:
            messagebox.showerror("Export Error", f"Error exporting orders: {e}")

    def run(self):
        """Start the application"""
        try:
            self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
            self.root.mainloop()
        except Exception as e:
            messagebox.showerror("Application Error", f"An error occurred: {e}")
        finally:
            self.cleanup_database()

    def on_closing(self):
        """Handle application closing"""
        if messagebox.askokcancel("Quit", "Do you want to quit the Mobile Shop application?"):
            self.cleanup_database()
            self.root.destroy()

    def cleanup_database(self):
        """Clean up database connections"""
        try:
            if hasattr(self, 'cursor') and self.cursor:
                self.cursor.close()
            if hasattr(self, 'connection') and self.connection and self.connection.is_connected():
                self.connection.close()
                print("Database connection closed successfully!")
        except Exception as e:
            print(f"Error closing database connection: {e}")

# Run the application
if __name__ == "__main__":
    try:
        app = MobileShop()
        app.run()
    except Exception as e:
        print(f"Failed to start application: {e}")
        messagebox.showerror("Startup Error", f"Failed to start application: {e}")
