class PhoneData:
    def __init__(self):
        self.phones = {
            "Vivo": [
                {"name": "Vivo Y35", "price": "18,499", "image": "images/vivo_y35.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Vivo V27 Pro", "price": "35,999", "image": "images/vivo_v27_pro.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Vivo T2x", "price": "16,990", "image": "images/vivo_t2x.jpg", "specs": "4GB RAM, 128GB Storage"},
                {"name": "Vivo X90", "price": "54,999", "image": "images/vivo_x90.jpg", "specs": "12GB RAM, 256GB Storage"},
                {"name": "Vivo V25 Pro", "price": "35,999", "image": "images/vivo_v25_pro.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Vivo Y16", "price": "11,999", "image": "images/vivo_y16.jpg", "specs": "3GB RAM, 64GB Storage"}
            ],
            "Samsung": [
                {"name": "Galaxy S23", "price": "74,999", "image": "images/samsung_s23.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Galaxy A54", "price": "38,999", "image": "images/samsung_a54.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Galaxy M34", "price": "18,999", "image": "images/samsung_m34.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Galaxy S22", "price": "57,999", "image": "images/samsung_s22.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Galaxy A34", "price": "30,999", "image": "images/samsung_a34.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Galaxy M14", "price": "14,990", "image": "images/samsung_m14.jpg", "specs": "4GB RAM, 128GB Storage"}
            ],
            "Apple": [
                {"name": "iPhone 15", "price": "79,900", "image": "images/iphone_15.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 14", "price": "69,900", "image": "images/iphone_14.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 13", "price": "59,900", "image": "images/iphone_13.jpg", "specs": "128GB Storage"},
                {"name": "iPhone 15 Pro", "price": "1,34,900", "image": "images/iphone_15_pro.jpg", "specs": "256GB Storage"},
                {"name": "iPhone 14 Pro", "price": "1,29,900", "image": "images/iphone_14_pro.jpg", "specs": "256GB Storage"},
                {"name": "iPhone SE", "price": "43,900", "image": "images/iphone_se.jpg", "specs": "64GB Storage"}
            ],
            "Realme": [
                {"name": "Realme 11 Pro", "price": "25,999", "image": "images/realme_11_pro.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Realme GT Neo 5", "price": "32,999", "image": "images/realme_gt_neo5.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Realme C55", "price": "13,999", "image": "images/realme_c55.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Realme 10 Pro+", "price": "24,999", "image": "images/realme_10_pro_plus.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "Realme Narzo 60", "price": "17,999", "image": "images/realme_narzo_60.jpg", "specs": "6GB RAM, 128GB Storage"},
                {"name": "Realme C53", "price": "10,999", "image": "images/realme_c53.jpg", "specs": "4GB RAM, 128GB Storage"}
            ],
            "OnePlus": [
                {"name": "OnePlus 11", "price": "56,999", "image": "images/oneplus_11.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus Nord 3", "price": "33,999", "image": "images/oneplus_nord_3.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus 10R", "price": "38,999", "image": "images/oneplus_10r.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus 11R", "price": "39,999", "image": "images/oneplus_11r.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "OnePlus Nord CE 3", "price": "26,999", "image": "images/oneplus_nord_ce3.jpg", "specs": "8GB RAM, 128GB Storage"},
                {"name": "OnePlus Nord CE 3 Lite", "price": "19,999", "image": "images/oneplus_nord_ce3_lite.jpg", "specs": "8GB RAM, 128GB Storage"}
            ],
            "Oppo": [
                {"name": "Oppo Reno 10 Pro", "price": "39,999", "image": "images/oppo_reno_10_pro.jpg", "specs": "12GB RAM, 256GB Storage"},
                {"name": "Oppo F23", "price": "25,999", "image": "images/oppo_f23.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo A98", "price": "18,999", "image": "images/oppo_a98.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo Find N3", "price": "1,39,999", "image": "images/oppo_find_n3.jpg", "specs": "16GB RAM, 512GB Storage"},
                {"name": "Oppo A78", "price": "17,999", "image": "images/oppo_a78.jpg", "specs": "8GB RAM, 256GB Storage"},
                {"name": "Oppo A58", "price": "13,999", "image": "images/oppo_a58.jpg", "specs": "6GB RAM, 128GB Storage"}
            ]
        }
    
    def get_phones(self):
        return self.phones
    
    def get_brands(self):
        return list(self.phones.keys())
    
    def get_phones_by_brand(self, brand):
        return self.phones.get(brand, [])
