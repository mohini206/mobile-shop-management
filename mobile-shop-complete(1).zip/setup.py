"""
Mobile Shop Application Setup Script
This script helps set up the Mobile Shop application with all dependencies.
"""

import os
import sys
import subprocess
import tkinter as tk
from tkinter import messagebox

def install_requirements():
    """Install required packages"""
    try:
        print("Installing required packages...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ All packages installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing packages: {e}")
        return False

def create_directories():
    """Create necessary directories"""
    directories = ["images", "exports", "backups"]
    
    for directory in directories:
        if not os.path.exists(directory):
            os.makedirs(directory)
            print(f"✅ Created directory: {directory}")
        else:
            print(f"📁 Directory already exists: {directory}")

def show_setup_complete():
    """Show setup completion message"""
    root = tk.Tk()
    root.withdraw()  # Hide the main window
    
    message = """
🎉 Mobile Shop Application Setup Complete! 🎉

✅ All dependencies installed
✅ Required directories created
✅ Application ready to run

Next Steps:
1. Run the application: python mobile_shop_complete.py
2. Configure your MySQL database when prompted
3. Add phone images using the Image Manager
4. Start selling phones!

📞 For support, contact: support@mobileshop.com
    """
    
    messagebox.showinfo("Setup Complete", message)
    root.destroy()

def main():
    """Main setup function"""
    print("🏪 Mobile Shop Application Setup")
    print("=" * 40)
    
    # Create directories
    print("\n📁 Creating directories...")
    create_directories()
    
    # Install requirements
    print("\n📦 Installing requirements...")
    if install_requirements():
        print("\n🎉 Setup completed successfully!")
        show_setup_complete()
    else:
        print("\n❌ Setup failed. Please check the error messages above.")
        input("Press Enter to exit...")

if __name__ == "__main__":
    main()
