import tkinter as tk
from tkinter import messagebox

class UserManager:
    def __init__(self):
        self.current_user = None
        self.users = {
            "admin": {"password": "admin123", "role": "admin"},
            "demo": {"password": "1234", "role": "customer"}
        }
    
    def safe_grab_set(self, window):
        """Safely set grab on window with error handling"""
        try:
            window.grab_set()
            return True
        except tk.TclError as e:
            print(f"Warning: Could not set window grab: {e}")
            return False
    
    def show_login(self, root, on_success_callback):
        """Show login window with dynamic user input"""
        login_window = tk.Toplevel(root)
        login_window.title("Customer Login")
        login_window.geometry("450x500")
        login_window.configure(bg="#0E43D0")
        login_window.resizable(False, False)
        
        # Center the window
        login_window.transient(root)
        
        # Try to set grab, but don't fail if it doesn't work
        self.safe_grab_set(login_window)
        
        # Main frame
        main_frame = tk.Frame(login_window, bg="#0E43D0", padx=40, pady=40)
        main_frame.pack(fill="both", expand=True)
        
        # Title
        title_label = tk.Label(
            main_frame,
            text="🔐 Customer Login",
            font=("Arial", 24, "bold"),
            fg="yellow",
            bg="#0E43D0"
        )
        title_label.pack(pady=(0, 30))
        
        # Customer Name field (Dynamic Input)
        tk.Label(
            main_frame,
            text="Customer Name:",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#0E43D0"
        ).pack(anchor="w", pady=(10, 5))
        
        customer_name_entry = tk.Entry(
            main_frame,
            font=("Arial", 14),
            width=25,
            relief="solid",
            bd=2
        )
        customer_name_entry.pack(pady=(0, 15))
        
        # Username field
        tk.Label(
            main_frame,
            text="Username:",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#0E43D0"
        ).pack(anchor="w", pady=(10, 5))
        
        username_entry = tk.Entry(
            main_frame,
            font=("Arial", 14),
            width=25,
            relief="solid",
            bd=2
        )
        username_entry.pack(pady=(0, 15))
        
        # Password field
        tk.Label(
            main_frame,
            text="Password:",
            font=("Arial", 14, "bold"),
            fg="white",
            bg="#0E43D0"
        ).pack(anchor="w", pady=(0, 5))
        
        password_entry = tk.Entry(
            main_frame,
            font=("Arial", 14),
            width=25,
            show="*",
            relief="solid",
            bd=2
        )
        password_entry.pack(pady=(0, 20))
        
        # Show password checkbox
        show_password_var = tk.BooleanVar()
        show_password_cb = tk.Checkbutton(
            main_frame,
            text="Show Password",
            variable=show_password_var,
            font=("Arial", 10),
            fg="white",
            bg="#0E43D0",
            selectcolor="#0E43D0",
            command=lambda: password_entry.config(show="" if show_password_var.get() else "*")
        )
        show_password_cb.pack(anchor="w", pady=(0, 10))
        
        def validate_login():
            customer_name = customer_name_entry.get().strip()
            username = username_entry.get().strip()
            password = password_entry.get().strip()
            
            # Check if fields are empty
            if not customer_name:
                messagebox.showerror("Error", "Please enter your name")
                customer_name_entry.focus()
                return
            
            if not username:
                messagebox.showerror("Error", "Please enter username")
                username_entry.focus()
                return
            
            if not password:
                messagebox.showerror("Error", "Please enter password")
                password_entry.focus()
                return
            
            # Validate credentials (flexible login system)
            if (username == "demo" and password == "1234") or (username == customer_name.lower().replace(" ", "") and password == "1234"):
                self.current_user = {
                    "name": customer_name,
                    "username": username,
                    "role": "customer"
                }
                messagebox.showinfo("Success", f"🎉 Welcome {customer_name}! Login Successful!")
                login_window.destroy()
                on_success_callback()
            else:
                messagebox.showerror("Error", "❌ Invalid credentials. Please try again.\n\nHint: Use 'demo' as username and '1234' as password")
                password_entry.delete(0, tk.END)
                password_entry.focus()
        
        # Login button
        login_btn = tk.Button(
            main_frame,
            text="🚀 Login",
            font=("Arial", 14, "bold"),
            bg="#4CAF50",
            fg="white",
            padx=30,
            pady=10,
            cursor="hand2",
            command=validate_login
        )
        login_btn.pack(pady=10)
        
        # Cancel button
        cancel_btn = tk.Button(
            main_frame,
            text="❌ Cancel",
            font=("Arial", 12),
            bg="#f44336",
            fg="white",
            padx=20,
            pady=8,
            cursor="hand2",
            command=login_window.destroy
        )
        cancel_btn.pack(pady=5)
        
        # Demo credentials info
        info_frame = tk.Frame(main_frame, bg="#0E43D0")
        info_frame.pack(pady=20)
        
        tk.Label(
            info_frame,
            text="Demo Login Instructions:",
            font=("Arial", 12, "bold"),
            fg="yellow",
            bg="#0E43D0"
        ).pack()
        
        tk.Label(
            info_frame,
            text="1. Enter your real name in 'Customer Name'",
            font=("Arial", 10),
            fg="lightblue",
            bg="#0E43D0"
        ).pack()
        
        tk.Label(
            info_frame,
            text="2. Use 'demo' as username",
            font=("Arial", 10),
            fg="lightblue",
            bg="#0E43D0"
        ).pack()
        
        tk.Label(
            info_frame,
            text="3. Use '1234' as password",
            font=("Arial", 10),
            fg="lightblue",
            bg="#0E43D0"
        ).pack()
        
        # Bind Enter key to login
        login_window.bind('<Return>', lambda event: validate_login())
        customer_name_entry.focus()
    
    def get_current_user(self):
        return self.current_user
    
    def logout(self):
        self.current_user = None
